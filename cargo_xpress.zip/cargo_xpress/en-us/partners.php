
    <!-- section begin -->
    <section id="section-partners">
        <div class="container">
                    <div class="col-md-12 text-center">
                        <h2 class="wow fadeInUp" data-wow-delay=".5s" data-wow-duration=".8s">Our family </h2>
                        <div class="small-border wow flipInY" data-wow-delay=".8s" data-wow-duration=".8s"></div>
                    </div>
            <div class="row">
                <div class="logo-partners">
                    <div class="col-md-2 col-xs-4">
                        <img class="wow fadeInRight" data-wow-delay=".2s" data-wow-duration=".6s" src="../img/logo/Logo ZENTRO Logistics (A lineas)-page-001.jpg" alt="">
                    </div>

                    <div class="col-md-2 col-xs-4">
                        <img class="wow fadeInRight" data-wow-delay=".5s" data-wow-duration=".5s" src="../img/logo/LOGO JWC.jpg" alt="">
                    </div>

                    <div class="col-md-2 col-xs-4">
                        <img class="wow fadeInRight" data-wow-delay=".8s" data-wow-duration=".5s" src="../img/logo/Logo ZENTRO Logistics (A lineas)-page-001.jpg" alt="">
                    </div>

                    <div class="col-md-2 col-xs-4">
                        <img class="wow fadeInRight" data-wow-delay="1.1s" data-wow-duration=".5s" src="../img/logo/LOGO JWC.jpg" alt="">
                    </div>

                    <div class="col-md-2 col-xs-4">
                        <img class="wow fadeInRight" data-wow-delay="1.4s" data-wow-duration=".5s" src="../img/logo/Logo ZENTRO Logistics (A lineas)-page-001.jpg" alt="">
                    </div>

                    <div class="col-md-2 col-xs-4">
                        <img class="wow fadeInRight" data-wow-delay="1.7s" data-wow-duration=".5s" src="img/logo/LOGO JWC.jpg" alt="">
                    </div>
                </div>

                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <!-- section close -->